import React, { useContext } from 'react';
import { ComposentContext } from './Notflix.js';

function MainChildImage () {

    const {dataResult} = useContext(ComposentContext);

    return (

        <div>

            <img src={dataResult.Poster} alt='Poster'/>

        </div>
        
    );

}

export default MainChildImage;