import React, { useState } from 'react';
import PlaceHolder from '../assets/PlaceHolder.jpg';

function Carousel () {

// actual carousel

    let numBtn = 0;

    const gauche = "gauche";

    const droite = "droite";

    const turnCarousel = (a) => {

        if (a === "gauche") {
            if (numBtn == 0) {

            } else {
                numBtn++

                document.getElementById('carouselContainer').style.justifyContent='flex-start';

                console.log(a);
            }
        } else if (a === "droite") {
            if (numBtn == 0) {
                numBtn--;

                document.getElementById('carouselContainer').style.justifyContent='flex-end';

                console.log(a);
            } else {
                
            }
        };

    };

    // carousel container

    const randomTitle = ["blade runner", "ninja", "terminator", "dragon", "bad", "rock", "hard", "love", "horror", "dog", "killer"];

    let [mySelection, setMySelection] = useState("");

    // fetch(`https://www.omdbapi.com/?apikey=38c8d091&s=${randomTitle[Math.floor(Math.random() * 11)]}`)
    //     .then((res) => res.json())
    //     .then(data => {

    //     setMySelection(data.Search)

    // });

    console.log(mySelection);

    return (

        <div className='carouselChild'>

            <h3 role='button'>Recomandé pour vous</h3>
            
            <div className='carouselAll'>

                <button onClick={() => turnCarousel(gauche)}>◄</button>

                <div id='carouselContainer'>

                    <img className='divCarousel' src={PlaceHolder}/>

                    <img className='divCarousel' src={PlaceHolder}/>

                    <img className='divCarousel' src={PlaceHolder}/>
                    
                    <img className='divCarousel' src={PlaceHolder}/>

                    <img className='divCarousel' src={PlaceHolder}/>

                    <img className='divCarousel' src={PlaceHolder}/>

                    <img className='divCarousel' src={PlaceHolder}/>

                </div>

                <button onClick={() => turnCarousel(droite)}>►</button>

            </div>

        </div>

    );

};

export default Carousel;