import React, { useContext } from 'react';
import { ComposentContext } from './Notflix.js';

function MainChildDescription () {

    const {dataResult} = useContext(ComposentContext);

    return (

        <div>
            
            <h2 id='typeResult'>{dataResult.Type}</h2>
        
            <div>
                <h3 id='title'>Title : {dataResult.Title}</h3>
                <h4 id='year'>Year : {dataResult.Year}</h4>
                <h4 id='country'>Country : {dataResult.Country}</h4>
                <h4 id='director'>Director : {dataResult.Director}</h4>
                <h4 id='genre'>Genre : {dataResult.Genre}</h4>
                <h4 id='runtime'>Duration : {dataResult.Runtime}</h4>
                <h4 id='rating'>imdbRating : {dataResult.imdbRating}</h4>
                <h4 id='votes'>imdbVotes : {dataResult.imdbVotes}</h4>
                <p id='actors'>Actors : {dataResult.Actors}</p>
                <p id='description'>Sinopsis : {dataResult.Plot}</p>
            </div>

        </div>

    );

};

export default MainChildDescription;