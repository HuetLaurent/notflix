import React, { useContext } from 'react';
import { ComposentContext } from './Notflix.js';

function HeaderParent () {

    const {setTitle} = useContext(ComposentContext);

    const notflix = 'notflix';
    const films = 'films';
    const series = 'series';

    const randomImdbId = (a) => {

        const randomTitle = ["blade runner", "ninja", "terminator", "dragon", "bad", "rock", "hard", "love", "horror", "dog", "killer"];

            if (a == 'notflix') {
                
                fetch(`https://www.omdbapi.com/?apikey=38c8d091&t=${randomTitle[Math.floor(Math.random() * 11)]}`)
                    .then((res) => res.json())
                    .then(data => {

                    setTitle(data.Title);

                    });

            } else if (a == 'films') {
                
                fetch(`https://www.omdbapi.com/?apikey=38c8d091&s=${randomTitle[Math.floor(Math.random() * 11)]}&type=movie`)
                    .then((res) => res.json())
                    .then(data => {

                    setTitle(data.Search[Math.floor(Math.random() * 11)].Title);

                    });

            } else if (a == 'series') {
                
                fetch(`https://www.omdbapi.com/?apikey=38c8d091&s=${randomTitle[Math.floor(Math.random() * 11)]}&type=series`)
                    .then((res) => res.json())
                    .then(data => {

                    setTitle(data.Search[Math.floor(Math.random() * 11)].Title);

                });

            };

    };

    return(

        <>
            <div className='Child-header'>
                <a href='#' onClick={() => randomImdbId(notflix)}><h2>NOTFLIX</h2></a>
                <a href='#' onClick={() => randomImdbId(films)}>Films</a>
                <a href='#' onClick={() => randomImdbId(series)}>Series</a>
            </div>

            <div className='Child-header'>
                <input id='titleSearchInput' type='text' placeholder='Title' onChange={e => setTitle(e.target.value)}/>
            </div>
        </>

    );

};

export default HeaderParent;