import '../styles/App.css';
import HeaderParent from './HeaderParent.js';
import MainParent from './MainParent.js';
import Notflix from './Notflix.js';

function App() {

  return (
    <div className="App">

      <Notflix>

      <header className="App-header">
        <HeaderParent/>
      </header>

      <main className="App-main">
        <MainParent/>
      </main>

    </Notflix>

    </div>
  );

}

export default App;
