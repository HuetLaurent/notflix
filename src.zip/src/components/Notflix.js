import React, { createContext, useEffect, useState } from 'react';

export const ComposentContext = createContext();

function Notflix (props) {
    const [title, setTitle] = useState("")

    const [dataResult, setDataResult] = useState("")

    useEffect(()=> {
        fetch(`https://www.omdbapi.com/?apikey=38c8d091&t=${title}`)
        .then((res) => res.json())
        .then(data => setDataResult(data));
    }, [title]);
    
    return (

        <>
           <ComposentContext.Provider value={{dataResult, setTitle}}>
                {props.children}
           </ComposentContext.Provider>
        </>

    );

}

export default Notflix;