import React from 'react';
import MainChildDescription from './MainChildDescription.js';
import MainChildImage from './MainChildImage.js';
import Carousel from './Carousel.js';

function MainParent () {

    return (

    <>
        <div className='Child-description'>

            <MainChildDescription/>

            <MainChildImage/>

        </div>

        <div className='Carousel'>

            <Carousel/>

        </div>
    </>

    );

};

export default MainParent;